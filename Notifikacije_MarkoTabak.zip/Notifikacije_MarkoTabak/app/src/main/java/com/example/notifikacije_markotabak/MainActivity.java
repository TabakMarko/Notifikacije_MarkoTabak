package com.example.notifikacije_markotabak;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    private static final int NOTIFICATION_ID_BASIC = 1;
    private static final int NOTIFICATION_ID_ADVANCED = 2;

    private NotificationManagerCompat notificationManager;
    private EditText inputText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        notificationManager = NotificationManagerCompat.from(this);
        inputText = findViewById(R.id.input_text);
    }

    public void showBasicNotification(View view) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel("basic_channel", "Basic Channel", NotificationManager.IMPORTANCE_DEFAULT);
            NotificationManager notificationManager = getSystemService(NotificationManager.class);
            notificationManager.createNotificationChannel(channel);
        }

        Notification notification = new NotificationCompat.Builder(this, "basic_channel")
                .setSmallIcon(R.drawable.ic_launcher_foreground)
                .setContentTitle("Jednostavna obavijest")
                .setContentText("Ovo je prikaz jednostavne obavijesti.")
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setCategory(NotificationCompat.CATEGORY_MESSAGE)
                .build();

        notificationManager.notify(NOTIFICATION_ID_BASIC, notification);
    }



    public void showAdvancedNotification(View view) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel("advanced_channel", "Advanced Channel", NotificationManager.IMPORTANCE_HIGH);
            channel.setDescription("This channel is used for advanced notifications.");
            channel.enableVibration(true);
            NotificationManager notificationManager = getSystemService(NotificationManager.class);
            notificationManager.createNotificationChannel(channel);
        }

        String text = inputText.getText().toString();
        Intent intent = new Intent(this, MainActivity.class);
        PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, intent, PendingIntent.FLAG_IMMUTABLE);

        Notification notification = new NotificationCompat.Builder(this, "advanced_channel")
                .setSmallIcon(R.drawable.ic_launcher_foreground)
                .setContentTitle("Obavijest s unesenim tekstom")
                .setContentText(text)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setCategory(NotificationCompat.CATEGORY_MESSAGE)
                .setContentIntent(pendingIntent)
                .setAutoCancel(true)
                .setStyle(new NotificationCompat.BigTextStyle().bigText(text))
                .setVibrate(new long[] { 1000, 1000, 1000 })
                .build();

        notificationManager.notify(NOTIFICATION_ID_ADVANCED, notification);
    }
}